<div class="course-form-ui" style="width:100%;height:100%;padding:8px;box-sizing:border-box;background:none;border:none;box-shadow:none;margin:0;">
	<h2 style="margin-bottom:24px;font-family:'Merriweather',serif;font-size:2rem;">Course Media</h2>
	<form>
		<div style="margin-bottom:18px;">
			<label for="coverImage" style="font-weight:600;font-size:1.1rem;">Cover Image <span style="color:#dc3545;">*</span></label>
			<input type="file" id="coverImage" name="coverImage" accept="image/*" required style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<div style="margin-bottom:18px;">
			<label for="introVideo" style="font-weight:600;font-size:1.1rem;">Intro Video</label>
			<input type="file" id="introVideo" name="introVideo" accept="video/*" style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<div style="margin-bottom:18px;">
			<label for="galleryImages" style="font-weight:600;font-size:1.1rem;">Gallery Images</label>
			<input type="file" id="galleryImages" name="galleryImages[]" accept="image/*" multiple style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<button type="submit" style="width:100%;padding:12px 0;background:#0d6efd;color:#fff;font-size:1.1rem;font-weight:700;border:none;border-radius:4px;cursor:pointer;">Save & Continue</button>
	</form>
</div>
