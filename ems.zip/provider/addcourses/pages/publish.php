<div class="course-form-ui" style="width:100%;height:100%;padding:8px;box-sizing:border-box;background:none;border:none;box-shadow:none;margin:0;">
	<h2 style="margin-bottom:24px;font-family:'Merriweather',serif;font-size:2rem;">Publish Course</h2>
	<form>
		<div style="margin-bottom:18px;">
			<label for="publishConfirm" style="font-weight:600;font-size:1.1rem;">Ready to publish?</label>
			<input type="checkbox" id="publishConfirm" name="publishConfirm" style="margin-right:8px;">
			<span style="font-size:1rem;">I confirm all details are correct and ready to publish.</span>
		</div>
		<button type="submit" style="width:100%;padding:12px 0;background:#0d6efd;color:#fff;font-size:1.1rem;font-weight:700;border:none;border-radius:4px;cursor:pointer;">Publish Course</button>
	</form>
</div>
