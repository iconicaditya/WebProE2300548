<div class="course-form-ui" style="width:100%;height:100%;padding:8px;box-sizing:border-box;background:none;border:none;box-shadow:none;margin:0;">
	<h2 style="margin-bottom:24px;font-family:'Merriweather',serif;font-size:2rem;">Course Price</h2>
	<form>
		<div style="margin-bottom:18px;">
			<label for="coursePrice" style="font-weight:600;font-size:1.1rem;">Price <span style="color:#dc3545;">*</span></label>
			<input type="number" id="coursePrice" name="coursePrice" placeholder="Enter price" required style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<div style="margin-bottom:18px;">
			<label for="discount" style="font-weight:600;font-size:1.1rem;">Discount (%)</label>
			<input type="number" id="discount" name="discount" placeholder="Enter discount percentage" style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<div style="margin-bottom:18px;">
			<label for="currency" style="font-weight:600;font-size:1.1rem;">Currency <span style="color:#dc3545;">*</span></label>
			<select id="currency" name="currency" required style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
				<option value="">Select currency</option>
				<option>USD</option>
				<option>NPR</option>
				<option>INR</option>
			</select>
		</div>
		<button type="submit" style="width:100%;padding:12px 0;background:#0d6efd;color:#fff;font-size:1.1rem;font-weight:700;border:none;border-radius:4px;cursor:pointer;">Save & Continue</button>
	</form>
</div>
