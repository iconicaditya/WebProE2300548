<div class="course-form-ui" style="width:100%;height:100%;padding:8px;box-sizing:border-box;background:none;border:none;box-shadow:none;margin:0;">
	<h2 style="margin-bottom:24px;font-family:'Merriweather',serif;font-size:2rem;">Resource Materials</h2>
	<form>
		<div style="margin-bottom:18px;">
			<label for="resourceTitle" style="font-weight:600;font-size:1.1rem;">Resource Title <span style="color:#dc3545;">*</span></label>
			<input type="text" id="resourceTitle" name="resourceTitle" placeholder="Enter resource title" required style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<div style="margin-bottom:18px;">
			<label for="resourceFile" style="font-weight:600;font-size:1.1rem;">Upload File <span style="color:#dc3545;">*</span></label>
			<input type="file" id="resourceFile" name="resourceFile" required style="width:100%;padding:10px 14px;border:1px solid #cbd5e1;border-radius:4px;font-size:1rem;">
		</div>
		<button type="button" style="width:100%;padding:10px 0;background:#0d6efd;color:#fff;font-size:1.1rem;font-weight:700;border:none;border-radius:4px;cursor:pointer;margin-bottom:18px;">Add Resource</button>
		<div style="margin-bottom:18px;">
			<label style="font-weight:600;font-size:1.1rem;">Added Resources</label>
			<ul style="background:#f3f6fa;padding:12px;border-radius:4px;min-height:40px;list-style:none;margin:0;">
				<li style="color:#415166;">No resources added yet.</li>
			</ul>
		</div>
		<button type="submit" style="width:100%;padding:12px 0;background:#0d6efd;color:#fff;font-size:1.1rem;font-weight:700;border:none;border-radius:4px;cursor:pointer;">Save & Continue</button>
	</form>
</div>
