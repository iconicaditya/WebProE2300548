<div class="course-form-ui">
	<h2>Course Basic Details</h2>
	<form id="courseBasicForm" autocomplete="off" enctype="multipart/form-data">
		<div class="form-row">
			<div class="form-group">
				<label for="title">Title <span class="required">*</span></label>
				<input type="text" id="title" name="title" placeholder="Enter course title" required>
			</div>
			<div class="form-group">
				<label for="subtitle">Subtitle</label>
				<input type="text" id="subtitle" name="subtitle" placeholder="Enter subtitle">
			</div>
			<div class="form-group">
				<label for="thumbnail">Course Thumbnail <span class="required">*</span></label>
				<input type="file" id="thumbnail" name="thumbnail" accept="image/*" required onchange="previewThumbnail(event)">
				<img id="thumbnailPreview" class="img-preview" style="display:none;margin-top:8px;max-width:140px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.07);border:1px solid #e2e8f0;"/>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group wide">
				<label>What you will learn</label>
				<div id="learnList"></div>
				<div class="add-row-btn"><input type="text" id="learnInput" placeholder="Add learning outcome"><button type="button" onclick="addLearn()">+ Add</button></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group wide">
				<label for="description">Course Description <span class="required">*</span></label>
				<textarea id="description" name="description" placeholder="Describe the course" required></textarea>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group wide">
				<label>Requirements</label>
				<div id="reqList"></div>
				<div class="add-row-btn"><input type="text" id="reqInput" placeholder="Add requirement"><button type="button" onclick="addReq()">+ Add</button></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group">
				<label for="duration">Duration</label>
				<input type="text" id="duration" name="duration" placeholder="e.g. 4 weeks">
			</div>
			<div class="form-group">
				<label for="lessons">Lessons</label>
				<input type="number" id="lessons" name="lessons" min="1" placeholder="e.g. 15">
			</div>
			<div class="form-group">
				<label for="language">Language</label>
				<input type="text" id="language" name="language" placeholder="e.g. English">
			</div>
			<div class="form-group">
				<label for="certificate">Certificate</label>
				<select id="certificate" name="certificate">
					<option value="yes">Yes</option>
					<option value="no">No</option>
				</select>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group wide">
				<label>What's Included</label>
				<div id="includedList"></div>
				<div class="add-row-btn"><input type="text" id="includedInput" placeholder="Add item"><button type="button" onclick="addIncluded()">+ Add</button></div>
			</div>
		</div>
		<button type="submit" class="submit-btn">Save & Continue</button>
	</form>
</div>

<style>
.course-form-ui {
	max-width: 820px;
	margin: 32px auto;
	background: #fff;
	border-radius: 12px;
	box-shadow: 0 4px 24px rgba(0,0,0,0.08);
	padding: 32px 28px 24px 28px;
	font-family: 'Segoe UI', 'Merriweather', serif;
}
.course-form-ui h2 {
	font-size: 2.1rem;
	font-weight: 700;
	margin-bottom: 28px;
	letter-spacing: 0.5px;
}
.form-row {
	display: flex;
	gap: 24px;
	margin-bottom: 18px;
	flex-wrap: wrap;
}
.form-group {
	flex: 1 1 220px;
	display: flex;
	flex-direction: column;
	margin-bottom: 0;
}
.form-group.wide {
	flex: 1 1 100%;
}
.form-group label {
	font-weight: 600;
	font-size: 1.08rem;
	margin-bottom: 7px;
}
.form-group input[type="text"],
.form-group input[type="number"],
.form-group select,
.form-group textarea {
	padding: 10px 14px;
	border: 1px solid #cbd5e1;
	border-radius: 5px;
	font-size: 1rem;
	background: #f8fafc;
	transition: border 0.2s;
}
.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
	border: 1.5px solid #0d6efd;
	outline: none;
}
.form-group textarea {
	min-height: 90px;
	resize: vertical;
}
.add-row-btn {
	display: flex;
	gap: 8px;
	margin-top: 7px;
}
.add-row-btn input {
	flex: 1;
}
.add-row-btn button {
	background: #0d6efd;
	color: #fff;
	border: none;
	border-radius: 4px;
	padding: 7px 16px;
	font-weight: 600;
	cursor: pointer;
	transition: background 0.18s;
}
.add-row-btn button:hover {
	background: #084298;
}
#learnList, #reqList, #includedList {
	margin-bottom: 0;
	margin-top: 7px;
}
.list-item {
	background: #f1f5f9;
	border-radius: 4px;
	padding: 7px 12px;
	margin-bottom: 5px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	font-size: 1rem;
}
.list-item button {
	background: none;
	border: none;
	color: #dc3545;
	font-size: 1.1rem;
	cursor: pointer;
	margin-left: 10px;
}
.required {
	color: #dc3545;
}
.submit-btn {
	width: 100%;
	padding: 13px 0;
	background: #0d6efd;
	color: #fff;
	font-size: 1.13rem;
	font-weight: 700;
	border: none;
	border-radius: 5px;
	cursor: pointer;
	margin-top: 28px;
	transition: background 0.18s;
}
.submit-btn:hover {
	background: #084298;
}
@media (max-width: 700px) {
	.course-form-ui { padding: 16px 4px; }
	.form-row { gap: 8px; }
}
</style>

.img-preview {
	display: block;
	width: 100%;
	max-width: 140px;
	border-radius: 8px;
	box-shadow: 0 2px 8px rgba(0,0,0,0.07);
	border: 1px solid #e2e8f0;
}
</style>

<script>
function previewThumbnail(event) {
	const input = event.target;
	const preview = document.getElementById('thumbnailPreview');
	if (input.files && input.files[0]) {
		const reader = new FileReader();
		reader.onload = function(e) {
			preview.src = e.target.result;
			preview.style.display = 'block';
		};
		reader.readAsDataURL(input.files[0]);
	} else {
		preview.src = '';
		preview.style.display = 'none';
	}
}
</script>

<script>
// Dynamic multi-input handlers
function addInputField(listId, placeholder) {
  const list = document.getElementById(listId);
  const div = document.createElement('div');
  div.className = 'list-item';
  div.innerHTML = `<input type='text' class='dynamic-input' placeholder='${placeholder}' oninput='updateHiddenInputs()'/> <button type='button' onclick='this.parentNode.remove(); updateHiddenInputs();'>&times;</button>`;
  list.appendChild(div);
  updateHiddenInputs();
}
function addLearn() { addInputField('learnList', 'What you will learn'); }
function addReq() { addInputField('reqList', 'Requirement'); }
function addIncluded() { addInputField('includedList', "What's included"); }

// Update hidden inputs with JSON arrays for form submission
function updateHiddenInputs() {
  document.getElementById('learnHidden').value = getInputValues('learnList');
  document.getElementById('reqHidden').value = getInputValues('reqList');
  document.getElementById('includedHidden').value = getInputValues('includedList');
}
function getInputValues(listId) {
  const inputs = document.getElementById(listId).querySelectorAll('.dynamic-input');
  return JSON.stringify(Array.from(inputs).map(input => input.value.trim()).filter(Boolean));
}

// Prevent form submit (frontend only)
document.getElementById('courseBasicForm').addEventListener('submit', function(e) {
  updateHiddenInputs();
  e.preventDefault();
  // For demonstration, show the collected data
  const data = {
    title: document.getElementById('title').value,
    subtitle: document.getElementById('subtitle').value,
    learn: JSON.parse(document.getElementById('learnHidden').value),
    description: document.getElementById('description').value,
    requirements: JSON.parse(document.getElementById('reqHidden').value),
    duration: document.getElementById('duration').value,
    lessons: document.getElementById('lessons').value,
    language: document.getElementById('language').value,
    certificate: document.getElementById('certificate').value,
    included: JSON.parse(document.getElementById('includedHidden').value)
  };
  alert('Frontend only. Data collected:\n' + JSON.stringify(data, null, 2));
});
</script>
<!-- Hidden inputs for dynamic lists -->
<input type="hidden" id="learnHidden" name="learn">
<input type="hidden" id="reqHidden" name="requirements">
<input type="hidden" id="includedHidden" name="included">
