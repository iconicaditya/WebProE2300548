
<div class="course-form-ui">
	<h2>Upload Course Videos</h2>
	<form id="videoUploadForm" autocomplete="off" enctype="multipart/form-data">
		<div class="form-row">
			<div class="form-group">
				<label for="videoTitle">Video Title <span class="required">*</span></label>
				<input type="text" id="videoTitle" name="videoTitle" placeholder="Enter video title" required>
			</div>
			<div class="form-group">
				<label for="sectionSelect">Section <span class="required">*</span></label>
				<select id="sectionSelect" name="sectionSelect" required>
					<option value="">Select section</option>
					<option value="1">Section 1</option>
					<option value="2">Section 2</option>
					<option value="3">Section 3</option>
					<option value="4">Section 4</option>
				</select>
			</div>
			<div class="form-group">
				<label for="videoFile">Upload Video <span class="required">*</span></label>
				<input type="file" id="videoFile" name="videoFile" accept="video/*" required onchange="previewVideo(event)">
				<video id="videoPreview" controls style="display:none;margin-top:8px;max-width:220px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.07);border:1px solid #e2e8f0;"></video>
			</div>
		</div>
		<button type="button" class="add-btn" onclick="addVideo()">Add Video</button>
		<div class="added-videos">
			<label>Added Videos</label>
			<ul id="videoList"></ul>
		</div>
		<button type="submit" class="submit-btn">Save & Continue</button>
	</form>
</div>

<style>
.course-form-ui {
	max-width: 820px;
	margin: 32px auto;
	background: #fff;
	border-radius: 12px;
	box-shadow: 0 4px 24px rgba(0,0,0,0.08);
	padding: 32px 28px 24px 28px;
	font-family: 'Segoe UI', 'Merriweather', serif;
}
.course-form-ui h2 {
	font-size: 2.1rem;
	font-weight: 700;
	margin-bottom: 28px;
	letter-spacing: 0.5px;
}
.form-row {
	display: flex;
	gap: 24px;
	margin-bottom: 18px;
	flex-wrap: wrap;
}
.form-group {
	flex: 1 1 220px;
	display: flex;
	flex-direction: column;
	margin-bottom: 0;
}
.form-group label {
	font-weight: 600;
	font-size: 1.08rem;
	margin-bottom: 7px;
}
.form-group input[type="text"],
.form-group select {
	padding: 10px 14px;
	border: 1px solid #cbd5e1;
	border-radius: 5px;
	font-size: 1rem;
	background: #f8fafc;
	transition: border 0.2s;
}
.form-group input:focus,
.form-group select:focus {
	border: 1.5px solid #0d6efd;
	outline: none;
}
.form-group input[type="file"] {
	margin-bottom: 7px;
}
.form-group textarea {
	min-height: 90px;
	resize: vertical;
}
.img-preview, video#videoPreview {
	display: block;
	width: 100%;
	max-width: 220px;
	border-radius: 8px;
	box-shadow: 0 2px 8px rgba(0,0,0,0.07);
	border: 1px solid #e2e8f0;
}
.add-btn {
	width: 100%;
	padding: 11px 0;
	background: #0d6efd;
	color: #fff;
	font-size: 1.1rem;
	font-weight: 700;
	border: none;
	border-radius: 4px;
	cursor: pointer;
	margin-bottom: 18px;
	margin-top: 10px;
	transition: background 0.18s;
}
.add-btn:hover {
	background: #084298;
}
.added-videos {
	margin-bottom: 18px;
}
.added-videos label {
	font-weight: 600;
	font-size: 1.08rem;
	margin-bottom: 7px;
	display: block;
}
#videoList {
	background: #f3f6fa;
	padding: 12px;
	border-radius: 4px;
	min-height: 40px;
	list-style: none;
	margin: 0;
}
#videoList li {
	color: #415166;
	margin-bottom: 8px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
}
#videoList li .video-title {
	font-weight: 500;
}
#videoList li .video-section {
	font-size: 0.98rem;
	color: #0d6efd;
	margin-left: 8px;
}
#videoList li button {
	background: none;
	border: none;
	color: #dc3545;
	font-size: 1.1rem;
	cursor: pointer;
	margin-left: 10px;
}
.required {
	color: #dc3545;
}
.submit-btn {
	width: 100%;
	padding: 13px 0;
	background: #0d6efd;
	color: #fff;
	font-size: 1.13rem;
	font-weight: 700;
	border: none;
	border-radius: 5px;
	cursor: pointer;
	margin-top: 28px;
	transition: background 0.18s;
}
.submit-btn:hover {
	background: #084298;
}
@media (max-width: 700px) {
	.course-form-ui { padding: 16px 4px; }
	.form-row { gap: 8px; }
}
</style>

<script>
function previewVideo(event) {
	const input = event.target;
	const preview = document.getElementById('videoPreview');
	if (input.files && input.files[0]) {
		const fileURL = URL.createObjectURL(input.files[0]);
		preview.src = fileURL;
		preview.style.display = 'block';
	} else {
		preview.src = '';
		preview.style.display = 'none';
	}
}

function addVideo() {
	const title = document.getElementById('videoTitle').value.trim();
	const section = document.getElementById('sectionSelect').value;
	const fileInput = document.getElementById('videoFile');
	const file = fileInput.files[0];
	const videoList = document.getElementById('videoList');
	if (!title || !section || !file) {
		alert('Please fill all fields and select a video.');
		return;
	}
	const li = document.createElement('li');
	li.innerHTML = `<span class='video-title'>${title}</span> <span class='video-section'>Section ${section}</span> <button type='button' onclick='this.parentNode.remove()'>&times;</button>`;
	videoList.appendChild(li);
	// Reset fields
	document.getElementById('videoTitle').value = '';
	document.getElementById('sectionSelect').value = '';
	fileInput.value = '';
	document.getElementById('videoPreview').src = '';
	document.getElementById('videoPreview').style.display = 'none';
}

document.getElementById('videoUploadForm').addEventListener('submit', function(e) {
	e.preventDefault();
	alert('Frontend only. Videos added: ' + document.getElementById('videoList').children.length);
});
</script>
