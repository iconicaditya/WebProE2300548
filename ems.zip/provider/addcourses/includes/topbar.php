<!-- Advanced Top Bar for Course Creation -->
<style>
/* Modern advanced step bar */
.topbar-steps {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: flex-start;
    background: #fff;
    padding: 12px 32px 12px 32px;
    gap: 18px;
    font-family: 'Segoe UI', Arial, sans-serif;
    box-shadow: 0 2px 12px rgba(15,23,42,0.06);
    border-radius: 0;
    margin: 0;
    max-width: none;
    width: 100%;
    overflow-x: auto;
    scrollbar-width: thin;
    position: fixed;
    top: 108px; /* Adjust to match navbar + subnav height */
    left: 0;
    z-index: 1040;
}
.topbar-step {
    display: flex;
    align-items: center;
        font-size: 18px;
    font-weight: 600;
    color: #415166;
    background: #f3f6fa;
        padding: 0 40px;
        height: 52px;
    border-radius: 0;
    box-shadow: 0 1px 4px rgba(15,23,42,0.04);
    text-decoration: none;
    cursor: pointer;
    transition: background 0.2s, color 0.2s, box-shadow 0.2s;
    position: relative;
    border: 2px solid transparent;
    outline: none;
    min-width: 120px;
    flex: 1 1 120px;
    max-width: 220px;
@media (max-width: 900px) {
    .topbar-steps {
        padding: 24px 12px 16px 12px;
        gap: 10px;
    }
    .topbar-step {
        font-size: 16px;
        padding: 0 16px;
        height: 44px;
        min-width: 100px;
        max-width: 160px;
    }
}
@media (max-width: 600px) {
    .topbar-steps {
        padding: 12px 4px 8px 4px;
        gap: 6px;
    }
    .topbar-step {
        font-size: 14px;
        padding: 0 8px;
        height: 36px;
        min-width: 80px;
        max-width: 120px;
    }
}
}
.topbar-step.active {
    color: #0f766e;
    background: #e0f2f1;
    border-color: #0f766e;
    box-shadow: 0 2px 8px rgba(15,23,42,0.10);
    z-index: 2;
}
.topbar-step:hover:not(.active), .topbar-step:focus:not(.active) {
    background: #e5e7eb;
    color: #0d6e84;
    box-shadow: 0 2px 8px rgba(15,23,42,0.08);
}
.topbar-step:active {
    background: #d1e7e0;
}
.topbar-step:not(:last-child)::after {
    content: '';
    display: block;
    width: 18px;
    height: 2px;
    background: #cbd5e1;
    margin-left: 12px;
    border-radius: 1px;
    position: absolute;
    right: -24px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 1;
}
.topbar-step.active:not(:last-child)::after {
    background: #0f766e;
}
.topbar-step:first-child {
    margin-left: 0;
}
.topbar-step:last-child {
    margin-right: 0;
}
</style>
<div class="topbar-steps" style="margin-bottom:64px;">
    <a class="topbar-step active" data-page="basicdetails.php" href="#">Basic Details</a>
    <a class="topbar-step" data-page="coursemedia.php" href="#">Course Media</a>
    <a class="topbar-step" data-page="modules.php" href="#">Modules</a>
    <a class="topbar-step" data-page="resources.php" href="#">Resource Materials</a>
    <a class="topbar-step" data-page="price.php" href="#">Course Price</a>
    <a class="topbar-step" data-page="publish.php" href="#">Publish</a>
</div>
<div id="step-content-wrapper" style="padding:32px 40px 0 40px; box-sizing:border-box;">
    <div id="step-content" style="margin-top:72px;"></div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    function loadStep(page, el) {
        fetch('pages/' + page)
            .then(resp => resp.text())
            .then(html => {
                document.getElementById('step-content').innerHTML = html;
                document.querySelectorAll('.topbar-step').forEach(a => a.classList.remove('active'));
                if (el) el.classList.add('active');
            });
    }
    document.querySelectorAll('.topbar-step').forEach(a => {
        a.addEventListener('click', function(e) {
            e.preventDefault();
            loadStep(this.getAttribute('data-page'), this);
        });
    });
    // Load default step
    loadStep('basicdetails.php', document.querySelector('.topbar-step.active'));
});
</script>
